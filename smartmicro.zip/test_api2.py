﻿import os, requests, json
API_KEY = os.environ.get('GEMINI_API_KEY', 'AQ.Ab8RN6JMgzZO5FgemDEAMR4j5DGPlLiVtTC9GE8lVwmIsfw7Zw')
URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent'
prompt = 'Return a JSON with reason and tip.'
resp = requests.post(URL, params={'key': API_KEY}, json={'contents': [{'parts': [{'text': prompt}]}], 'generationConfig': {'temperature': 0.3, 'maxOutputTokens': 300, 'responseMimeType': 'application/json'}})
print(json.dumps(resp.json(), indent=2))
